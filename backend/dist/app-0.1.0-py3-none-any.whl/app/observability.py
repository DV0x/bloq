def init_observability():
    pass
